import { Injectable } from '@angular/core';
import { Hero } from './hero';
import { HEROES } from './mock-heroes';
import {Observable, of } from 'rxjs';
import {MessageService} from './message.service';
import {HttpClient , HttpHeaders} from '@angular/common/http';
import {catchError, map, tap} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  private heroUrl: string = 'http://localhost:9093/hero/'; 
  private user: string = 'user:userpass'
  private httpOptions = {
        headers: new HttpHeaders({ 'Contect-Type': 'application/json','Authorization': 'Basic ' + btoa('user:userpass')})
  }; 

  constructor(private messageService: MessageService , private httpClient: HttpClient) { }

  getHeroes(): Observable<Hero[]> {
    this.messageService.add('Fetchnng messages from remote server');
    return this.httpClient.get<Hero[]>(this.heroUrl +'getheros' , this.httpOptions)
    .pipe(
      tap((heros: Hero[]) => console.log('Return heroes length:' + heros.length)),
       catchError(this.handleError('getHeros' , [])) 
    );
  }
   getHero(id: number): Observable<Hero> {
        // TODO: send the message _after_ fetching the hero
        this.messageService.add('HeroService: fetched hero id='+id);
        return this.httpClient.get<Hero>(this.heroUrl+ id , this.httpOptions);
      /*  .pipe(
            tap((hero:Hero)=> console.log('Fetched hero  from  server->'+ hero.name)), 
            catchError( this.handleError('getHeroby ${id}' , []))
        ) ;  */
    }

    /**
 * Handle Http operation that failed.
 * Let the app continue.
 * @param operation - name of the operation that failed
 * @param result - optional value to return as the observable result
 */
private handleError<T> (operation: string, result?: T) {
  return (error: any): Observable<T> => {
 
    // TODO: send the error to remote logging infrastructure
    console.error('Error caught'+error); // log to console instead
 
    // TODO: better job of transforming error for user consumption
  
    console.log(`${operation} failed: ${error.message}`);
 
    // Let the app keep running by returning an empty result.
    return of(result as T);
  };
}
}
