import {Hero} from './hero' ; 

export const HEROES: Hero[] = [
  { id: 11, name: 'Mr. Nice', filmname: 'Mr. Natwarlal' },
  { id: 12, name: 'Narco' , filmname: 'Mr. Natwarlal'},
  { id: 13, name: 'Bombasto', filmname: 'Mr. Natwarlal'},
  { id: 14, name: 'Celeritas', filmname: 'Mr. Natwarlal'},
  { id: 15, name: 'Magneta' , filmname: 'Mr. Natwarlal'},
  { id: 16, name: 'RubberMan', filmname: 'Mr. Natwarlal'},
  { id: 17, name: 'Dynama', filmname: 'Mr. Natwarlal' },
  { id: 18, name: 'Dr IQ', filmname: 'Mr. Natwarlal' },
  { id: 19, name: 'Magma' , filmname: 'Mr. Natwarlal'},
  { id: 20, name: 'Tornado', filmname: 'Mr. Natwarlal'}
]; 